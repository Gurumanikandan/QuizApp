package com.project.quizAppUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizAppUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
